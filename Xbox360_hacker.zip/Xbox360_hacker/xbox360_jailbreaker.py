import os

def jailbreak_xbox():
    os.system("sudo chmod -R 777 /dev/xbox")
    os.system("sudo echo '1' > /sys/class/xbox/jailbreak")
    print("Xbox successfully jailbroken. Enjoy your newfound freedom!")

if __name__ == "__main__":
    jailbreak_xbox()
